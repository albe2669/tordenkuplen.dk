
    <footer class="footer-area">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-3 col-sm-6">
                    <div class="single-footer-widget footer_1">
                        <h4>Om denne side</h4>
                        <p> Denne side er baseret på en intern joke om tordenkuplen fra filmen "Mad Max i tordenkuplen", produceret i 1985</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-footer-widget footer_2">
                        <h4>Kontakt</h4>
                        <div class="contact_info">
                            <p><span>Adresse :</span> Pim Mulierlaan 1, 8443 DA Heerenveen, Holland </p>
                            <p><span>Telef :</span> +31 309 055 (1992) </p>
                            <p><span>Email :</span> dev@tordenkuplen.dk </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer part end-->
